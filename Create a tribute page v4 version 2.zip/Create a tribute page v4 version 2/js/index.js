var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 3500); // Change image every 5.5 seconds
}

// set the width of the side navigation to 250px and the left margin of the page content to 250px and add a black background color to body//
function openNav(){
    document.getElementById("mySidenav").style.width ="250px";
    document.getElementById("main").style.marginLeft ="250";
    document.body.style.backgroundColor ="rgba(0,0,0,0.4)";
}

//set the width of the side navigation to 0 and the left margin of the page content to 0, and the background color of body to white //
function closeNav(){
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft ="0";
    document.body.style.backgroundColor ="black";
}